# telegramclonebot
Credit Moediyu

Moded by MyatThawMaung

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/NoobFromMM/telegramclonebot)
